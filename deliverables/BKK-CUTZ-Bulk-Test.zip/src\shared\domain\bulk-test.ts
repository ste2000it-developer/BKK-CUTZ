import type { Barber, PosBranch } from "./pos-attendance";
import { createTransactionId, makeTransaction } from "./pos-payment";
import { calculatePosServiceTotal, getPosRangeBounds, getHaircutDiscountAmount, type SelectedService } from "./pos-services";
import { parseTestSaleTime } from "./test-sale-time";
import type { ServiceRecord } from "../firebase/repositories/services";

export type BulkRow = { id: string; date: string; time: string; barberId: string; services: SelectedService[] };
export function newBulkRow(date: string): BulkRow {
  return { id: createTransactionId(), date, time: "", barberId: "", services: [] };
}
export function validateBulkRow(row: BulkRow, barbers: readonly Barber[], catalog: readonly ServiceRecord[]): string[] {
  const errors: string[] = [];
  if (!row.date) errors.push("กรุณาเลือกวันที่");
  if (!row.time) errors.push("กรุณากรอกเวลา");
  try {
    parseTestSaleTime(`${row.date}T${row.time}`);
    if (Number(row.date.slice(0, 4)) >= 2400) errors.push("กรุณาใช้ปี ค.ศ. เช่น 2026 สำหรับ พ.ศ. 2569");
  } catch { errors.push("วันที่หรือเวลาไม่ถูกต้อง"); }
  if (!barbers.some((barber) => barber.id === row.barberId)) errors.push("ยังไม่ได้เลือกช่าง");
  if (!row.services.length) errors.push("กรุณาเลือกอย่างน้อย 1 บริการ");
  for (const selected of row.services) {
    const service = catalog.find((item) => item.id === selected.id && item.active === true);
    if (!service) { errors.push(`ไม่พบบริการ ${selected.name} ในรายการปัจจุบัน`); continue; }
    const price = selected.price;
    if (!Number.isFinite(price)) { errors.push(`ราคา ${selected.name} ไม่ถูกต้อง`); continue; }
    if (service.type === "choice") {
      const values = (service.choices || []).map(Number).filter(Number.isFinite);
      if (service.serviceCode === "shave" || service.serviceCode === "trim") {
        const { min, max } = getPosRangeBounds(service);
        if (!Number.isInteger(price) || price < min || price > max) errors.push(`ราคา ${selected.name} ต้องเป็นจำนวนเต็มระหว่าง ${min}-${max} บาท`);
      } else if (!values.includes(price)) errors.push(`กรุณาเลือกราคา ${selected.name} จากรายการ`);
    } else if (service.type === "custom") {
      if (price < 0 || !selected.detail?.trim()) errors.push(`กรุณาตรวจสอบราคาและรายละเอียด ${selected.name}`);
    } else if (service.type === "free_cut" || service.type === "half_cut") {
      const target = row.services.find((item) => item.serviceCode === selected.targetServiceCode && (item.serviceCode === "haircut" || item.serviceCode === "kids"));
      if (!target || price !== -getHaircutDiscountAmount(service, target)) errors.push(`กรุณาเลือกส่วนลด ${selected.name} ใหม่`);
    } else if (price < 0 || price !== Number(service.price || 0)) errors.push(`ราคา ${selected.name} ไม่ตรงกับรายการปัจจุบัน`);
  }
  if (!(calculatePosServiceTotal(row.services) > 0)) errors.push("ยอดรวมต้องมากกว่า 0 บาท");
  return errors;
}
export function prepareBulkTransactions(branch: PosBranch, rows: readonly BulkRow[], barbers: readonly Barber[], catalog: readonly ServiceRecord[]) {
  const errors = rows.flatMap((row, index) => validateBulkRow(row, barbers, catalog).map((message) => `แถว ${index + 1}: ${message}`));
  if (!rows.length || errors.length) throw new Error(errors.join("\n") || "กรุณาเพิ่มรายการ");
  return rows.map((row) => makeTransaction(branch, {
    barber: barbers.find((barber) => barber.id === row.barberId)!, services: row.services, testSaleTime: `${row.date}T${row.time}`,
  }, "cash", 0, row.id));
}
