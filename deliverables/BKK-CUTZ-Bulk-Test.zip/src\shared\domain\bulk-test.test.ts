import { describe, expect, it } from "vitest";
import { newBulkRow, prepareBulkTransactions, validateBulkRow, type BulkRow } from "./bulk-test";
import { makeSelectedService } from "./pos-services";
import { buildPayoutRows, getPayoutCycleForWorkDate } from "./payout";
import type { ServiceRecord } from "../firebase/repositories/services";

const branch = { id: "b", name: "Branch", serviceGroup: "g" };
const barbers = [{ id: "barber01", name: "A" }, { id: "barber02", name: "B" }];
const catalog: ServiceRecord[] = [
  { id: "cut", name: "Cut", groupId: "g", active: true, type: "fixed", serviceCode: "haircut", price: 300 },
  { id: "wash", name: "Wash", groupId: "g", active: true, type: "fixed", price: 50 },
  { id: "trim", name: "Trim", groupId: "g", active: true, type: "choice", serviceCode: "trim", choices: [150, 200] },
];
const row = (): BulkRow => ({ ...newBulkRow("2026-09-01"), time: "09:35", barberId: "barber01", services: catalog.map((service, index) => makeSelectedService(service, [300, 50, 180][index])) });
describe("bulk sale validation and existing report compatibility", () => {
  it("creates one multi-service bill with the entered Bangkok time and existing schema", () => {
    const draft = row();
    const [transaction] = prepareBulkTransactions(branch, [draft], barbers, catalog);
    expect(transaction).toMatchObject({ id: draft.id, branchId: "b", barberId: "barber01", serviceTotal: 530, total: 530, grandTotal: 530, tipAmount: 0, paymentMethod: "cash", source: "pos", dateKey: "2026-09-01", createdAt: "2026-09-01T02:35:00.000Z" });
    expect(transaction.services).toHaveLength(3);
    const [payout] = buildPayoutRows([transaction], []);
    expect(payout).toMatchObject({ commissionAmount: 215, guaranteeAmount: 285, totalAmount: 500, transactionCount: 1 });
    expect(getPayoutCycleForWorkDate(transaction.dateKey)?.payoutDateKey).toBe("2026-09-16");
  });
  it("allows many bills at identical times and dates, and preserves date across added rows", () => {
    const first = row(), second = row();
    second.barberId = "barber02";
    const transactions = prepareBulkTransactions(branch, [first, second], barbers, catalog);
    expect(transactions[0].id).not.toBe(transactions[1].id);
    expect(newBulkRow(first.date)).toMatchObject({ date: first.date, time: "", barberId: "", services: [] });
  });
  it.each([150, 160, 170, 180, 190, 200])("accepts configured range price %s", (price) => {
    const draft = row(); draft.services[2].price = price;
    expect(validateBulkRow(draft, barbers, catalog)).toEqual([]);
  });
  it.each([149, 201, 170.5, NaN, Infinity])("rejects invalid range price %s", (price) => {
    const draft = row(); draft.services[2].price = price;
    expect(validateBulkRow(draft, barbers, catalog).length).toBeGreaterThan(0);
  });
  it.each([['2026-02-30', '09:35'], ['2569-09-01', '09:35'], ['2026-09-01', '24:00'], ['', ''], ['2026-09-01', '']])("rejects malformed or Buddhist-year storage: %s %s", (date, time) => {
    expect(validateBulkRow({ ...row(), date, time }, barbers, catalog).length).toBeGreaterThan(0);
  });
  it("validates every row before preparing a batch and reports row numbers", () => {
    const bad = { ...row(), barberId: "missing", services: [] };
    expect(() => prepareBulkTransactions(branch, [row(), bad], barbers, catalog)).toThrow("แถว 2:");
  });
  it("retains Bangkok date at midnight even though UTC is the previous day", () => {
    const [transaction] = prepareBulkTransactions(branch, [{ ...row(), time: "00:05" }], barbers, catalog);
    expect(transaction.createdAt).toBe("2026-08-31T17:05:00.000Z");
    expect(transaction.dateKey).toBe("2026-09-01");
  });
});
