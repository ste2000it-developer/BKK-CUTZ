import { doc, serverTimestamp, writeBatch } from "firebase/firestore";
import { db } from "../client";
import type { PosTransaction } from "../../domain/pos-payment";

// Small batches also leave room for security-rule document lookups (20 per batch).
// Keep payloads well below the 10 MiB request limit; indexes add server-side size.
export const BULK_CHUNK_SIZE = 10;
export function chunkBulkTransactions(rows: readonly PosTransaction[]): PosTransaction[][] {
  const chunks: PosTransaction[][] = [];
  let chunk: PosTransaction[] = [], bytes = 0;
  for (const row of rows) {
    const size = new TextEncoder().encode(JSON.stringify(row)).length;
    if (size > 500_000) throw new Error(`รายการ ${row.id} มีข้อมูลมากเกินไป`);
    if (chunk.length && (chunk.length >= BULK_CHUNK_SIZE || bytes + size > 1_000_000)) {
      chunks.push(chunk); chunk = []; bytes = 0;
    }
    chunk.push(row); bytes += size;
  }
  if (chunk.length) chunks.push(chunk);
  return chunks;
}
async function commitChunk(rows: readonly PosTransaction[]) {
  const batch = writeBatch(db);
  for (const transaction of rows) batch.set(doc(db, "transactions", transaction.id), { ...transaction, createdAtServer: serverTimestamp() });
  await batch.commit();
}
export async function saveBulkTransactions(rows: readonly PosTransaction[], onProgress: (savedIds: string[]) => void, commit = commitChunk) {
  const chunks = chunkBulkTransactions(rows);
  const savedIds: string[] = [];
  for (const chunk of chunks) {
    try { await commit(chunk); }
    catch (error) {
      return { savedIds, failedIds: chunk.map((row) => row.id), error: error instanceof Error ? error.message : "บันทึกไม่สำเร็จ" };
    }
    savedIds.push(...chunk.map((row) => row.id));
    onProgress([...savedIds]);
  }
  return { savedIds, failedIds: [] as string[], error: "" };
}
