import { useEffect, useRef, useState } from "react";
import { AppSelect } from "../../../admin/components/AppSelect";
import type { Barber, PosBranch } from "../../../shared/domain/pos-attendance";
import type { PosTransaction } from "../../../shared/domain/pos-payment";
import { newBulkRow, prepareBulkTransactions, validateBulkRow, type BulkRow } from "../../../shared/domain/bulk-test";
import { calculatePosServiceTotal } from "../../../shared/domain/pos-services";
import { currentThaiSaleTime } from "../../../shared/domain/test-sale-time";
import { listActiveBarbers } from "../../../shared/firebase/repositories/attendance";
import { listServicesByGroup, type ServiceRecord } from "../../../shared/firebase/repositories/services";
import { chunkBulkTransactions, saveBulkTransactions } from "../../../shared/firebase/repositories/bulk-transactions";
import { ServiceSelectionPage } from "../services/ServiceSelectionPage";
import "./bulk-test.css";

const money = (value: number) => value.toLocaleString("th-TH", { maximumFractionDigits: 2 });
export function BulkTestPage({ branch, onClose }: { branch: PosBranch; onClose: () => void }) {
  const [rows, setRows] = useState<BulkRow[]>(() => [newBulkRow(currentThaiSaleTime().slice(0, 10))]);
  const [barbers, setBarbers] = useState<Barber[]>([]);
  const [catalog, setCatalog] = useState<ServiceRecord[]>([]);
  const [ready, setReady] = useState(false);
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [editor, setEditor] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState<string[]>([]);
  const [attempted, setAttempted] = useState(false);
  const pending = useRef(false);
  const prepared = useRef<PosTransaction[] | null>(null);
  const savedRef = useRef<string[]>([]);
  const dialog = useRef<HTMLDialogElement>(null);
  const activeRow = rows.find((row) => row.id === editor);
  const complete = rows.length > 0 && saved.length === rows.length;
  useEffect(() => {
    const element = dialog.current;
    if (editor && element) element.showModal();
    return () => { element?.close(); };
  }, [editor]);
  useEffect(() => {
    let live = true;
    void Promise.all([listActiveBarbers(), listServicesByGroup(branch.serviceGroup)]).then(([people, services]) => {
      if (live) { setBarbers(people); setCatalog(services.filter((item) => item.active === true)); setReady(true); }
    }).catch((error: unknown) => { if (live) setMessage(error instanceof Error ? error.message : "โหลดข้อมูลไม่สำเร็จ"); });
    return () => { live = false; };
  }, [branch.serviceGroup]);
  useEffect(() => {
    const warn = (event: BeforeUnloadEvent) => {
      if (!complete && rows.some((row) => row.time || row.barberId || row.services.length)) event.preventDefault();
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [rows, complete]);
  function update(id: string, change: Partial<BulkRow>) {
    setRows((current) => current.map((row) => row.id === id ? { ...row, ...change } : row));
    setErrors((current) => ({ ...current, [id]: [] }));
  }
  function addRow() {
    setRows((current) => [...current, newBulkRow(current.at(-1)?.date || currentThaiSaleTime().slice(0, 10))]);
  }
  function close() {
    if (!complete && rows.some((row) => row.time || row.barberId || row.services.length) && !window.confirm("มีรายการที่ยังไม่บันทึก ต้องการออกจากหน้านี้หรือไม่?")) return;
    onClose();
  }
  async function save() {
    if (pending.current || complete) return;
    const issues = Object.fromEntries(rows.map((row) => [row.id, validateBulkRow(row, barbers, catalog)]));
    setErrors(issues);
    if (Object.values(issues).some((messages) => messages.length) || !rows.length) { setMessage("กรุณาแก้ไขแถวที่แจ้งเตือนก่อนบันทึก"); return; }
    pending.current = true; setBusy(true); setMessage("");
    try {
      const transactions = prepared.current ?? prepareBulkTransactions(branch, rows, barbers, catalog);
      chunkBulkTransactions(transactions);
      prepared.current = transactions;
      setAttempted(true);
      const previous = savedRef.current;
      const result = await saveBulkTransactions(prepared.current.filter((row) => !previous.includes(row.id)), (ids) => {
        savedRef.current = [...previous, ...ids]; setSaved(savedRef.current);
      });
      if (result.error) {
        setErrors(Object.fromEntries(result.failedIds.map((id) => [id, [`บันทึกไม่สำเร็จ: ${result.error}`]])));
        setMessage(`บันทึกสำเร็จ ${savedRef.current.length} / ${rows.length} รายการ ชุดที่มีปัญหาหยุดแล้ว กดบันทึกต่อด้วยข้อมูลและ ID เดิม`);
      } else setMessage(`บันทึกสำเร็จ ${rows.length} รายการ รวม ${money(rows.reduce((sum, row) => sum + calculatePosServiceTotal(row.services), 0))} บาท`);
    } catch (error) { setMessage(error instanceof Error ? error.message : "บันทึกไม่สำเร็จ"); }
    finally { pending.current = false; setBusy(false); }
  }
  return <main className="app bulk-test">
    <header className="app-header"><div><div className="system-brand">BKK-CUTZ</div><div className="system-subbrand">โหมดทดสอบ</div></div><strong>สาขา {branch.name || branch.id}</strong><button className="secondary-button" disabled={busy} onClick={close}>กลับ POS</button></header>
    <section className="bulk-heading"><div><h1>ลงข้อมูลย้อนหลัง / Bulk Test</h1><p>1 แถว = 1 บิล · เวลาไทย · เลือกวันที่ได้ทุกเดือน (ปี ค.ศ. 2026 = พ.ศ. 2569)</p><p>บันทึกเป็นเงินสด ไม่มีทิป ลงฐานข้อมูลจริง และปรากฏในประวัติและรายงานของสาขานี้</p></div><button className="secondary-button" disabled={!ready || attempted} onClick={addRow}>+ เพิ่มรายการ</button></section>
    {!ready && !message && <p role="status">กำลังโหลดช่างและบริการ...</p>}
    {message && <p className="bulk-message" role="status">{message}</p>}
    <div className="bulk-table-wrap"><table className="bulk-table"><thead><tr><th>#</th><th>วันที่ (ค.ศ.)</th><th>เวลาไทย</th><th>ช่าง</th><th>Services</th><th>ยอดรวม</th><th>จัดการ</th></tr></thead><tbody>{rows.map((row, index) => <tr key={row.id} className={errors[row.id]?.length ? "bulk-invalid" : ""}>
      <td>{index + 1}{saved.includes(row.id) && <span aria-label="บันทึกแล้ว"> ✓</span>}</td>
      <td><input aria-label={`วันที่ แถว ${index + 1}`} type="date" disabled={attempted} value={row.date} onChange={(event) => update(row.id, { date: event.target.value })} /></td>
      <td><input aria-label={`เวลา แถว ${index + 1}`} type="time" disabled={attempted} value={row.time} onChange={(event) => update(row.id, { time: event.target.value })} /></td>
      <td><AppSelect aria-label={`ช่าง แถว ${index + 1}`} value={row.barberId} disabled={!ready || attempted} onChange={(barberId) => update(row.id, { barberId })}><option value="">เลือกช่าง</option>{barbers.map((barber) => <option key={barber.id} value={barber.id}>{barber.name || barber.id}</option>)}</AppSelect></td>
      <td><button className="bulk-services" disabled={!ready || attempted} onClick={() => setEditor(row.id)}>{row.services.length ? row.services.map((service) => `${service.name} ${money(service.price)}`).join(", ") : "+ เลือกบริการ"}</button>{errors[row.id]?.length > 0 && <ul className="bulk-errors" role="alert">{errors[row.id].map((error, i) => <li key={i}>แถว {index + 1}: {error}</li>)}</ul>}</td>
      <td className="bulk-total">{money(calculatePosServiceTotal(row.services))}</td>
      <td><div className="bulk-actions"><button disabled={attempted} onClick={() => setRows((current) => { const copy = { ...row, id: newBulkRow(row.date).id, services: row.services.map((service) => ({ ...service })) }; const next = [...current]; next.splice(index + 1, 0, copy); return next; })}>ทำสำเนา</button><button disabled={attempted} onClick={() => setRows((current) => current.filter((item) => item.id !== row.id))}>ลบ</button></div></td>
    </tr>)}</tbody></table></div>
    {activeRow && <dialog ref={dialog} className="bulk-editor" aria-label="เลือกบริการสำหรับบิล" onCancel={() => setEditor(null)}><h2>บริการแถว {rows.indexOf(activeRow) + 1}</h2><ServiceSelectionPage key={activeRow.id} services={catalog} barber={barbers.find((barber) => barber.id === activeRow.barberId) || { id: "", name: "เลือกบริการ" }} initialSelected={activeRow.services} onBack={() => setEditor(null)} onCheckout={(services) => { update(activeRow.id, { services }); setEditor(null); }} /><button className="secondary-button" onClick={() => { update(activeRow.id, { services: [] }); setEditor(null); }}>ล้างบริการในแถวนี้</button></dialog>}
    <footer className="bulk-footer"><div><strong>{rows.length} รายการ | รวม {money(rows.reduce((sum, row) => sum + calculatePosServiceTotal(row.services), 0))} บาท</strong><div role="status">บันทึก {saved.length} / {rows.length}</div></div>{complete ? <button className="primary-button" onClick={() => { prepared.current = null; savedRef.current = []; setSaved([]); setAttempted(false); setErrors({}); setMessage(""); setRows([newBulkRow(rows.at(-1)?.date || "")]); }}>เริ่มชุดใหม่</button> : <button className="primary-button" disabled={!ready || busy || !rows.length || Boolean(editor)} onClick={() => void save()}>{busy ? "กำลังบันทึก..." : `${attempted ? "บันทึกต่อ" : "บันทึกทั้งหมด"} ${rows.length - saved.length} รายการ`}</button>}</footer>
  </main>;
}
