import { renderToStaticMarkup } from "react-dom/server";
import { expect, it } from "vitest";
import { ServiceSelectionPage } from "./ServiceSelectionPage";
import { makeSelectedService } from "../../../shared/domain/pos-services";
const service = { id: "cut", groupId: "g", name: "Cut", type: "fixed", price: 300 };
const props = { services: [service], barber: { id: "b", name: "Barber" }, onBack: () => {}, onCheckout: () => {} };
it("normal POS selection still starts empty and cannot checkout", () => {
  const html = renderToStaticMarkup(<ServiceSelectionPage {...props} />);
  expect(html).toContain("ยังไม่ได้เลือกบริการ");
  expect(html).toMatch(/disabled=""[^>]*>ยืนยันรายการ/);
});
it("bulk editing restores selected service snapshots without modifying the input", () => {
  const selected = makeSelectedService(service, 300);
  const html = renderToStaticMarkup(<ServiceSelectionPage {...props} initialSelected={[selected]} />);
  expect(html).toContain("service-button selected");
  expect(html).toContain("300 บาท");
  expect(html).not.toMatch(/disabled=""[^>]*>ยืนยันรายการ/);
  expect(selected.price).toBe(300);
});
