import { beforeEach, expect, it, vi } from "vitest";
const mock = vi.hoisted(() => ({ set: vi.fn(), commit: vi.fn() }));
vi.mock("../client", () => ({ db: {} }));
vi.mock("firebase/firestore", () => ({
  doc: (_db: unknown, ...path: string[]) => path.join("/"),
  serverTimestamp: () => "SERVER_TIME", writeBatch: () => mock,
}));
import { chunkBulkTransactions, saveBulkTransactions } from "./bulk-transactions";
import { makeTransaction } from "../../domain/pos-payment";
const transactions = (count: number) => Array.from({ length: count }, (_, index) => makeTransaction(
  { id: "branch", name: "Branch", serviceGroup: "g" },
  { barber: { id: "barber01", name: "A" }, services: [{ id: "s", serviceCode: "haircut", name: "Cut", type: "fixed", price: 300, basePrice: 300 }], testSaleTime: "2026-09-01T09:35" }, "cash", 0, `tx-${index}`));
beforeEach(() => { vi.clearAllMocks(); mock.commit.mockResolvedValue(undefined); });
it("saves 247 bills in bounded chunks to the existing collection", async () => {
  const rows = transactions(247), progress = vi.fn();
  const result = await saveBulkTransactions(rows, progress);
  expect(mock.commit).toHaveBeenCalledTimes(25);
  expect(mock.set).toHaveBeenCalledTimes(247);
  expect(mock.set).toHaveBeenNthCalledWith(1, "transactions/tx-0", { ...rows[0], createdAtServer: "SERVER_TIME" });
  expect(progress.mock.calls.map(([ids]) => ids.length)).toEqual([...Array.from({ length: 24 }, (_, i) => (i + 1) * 10), 247]);
  expect(result.savedIds).toHaveLength(247);
});
it("stops at the failed chunk and retries remaining bills using the same IDs", async () => {
  const rows = transactions(25);
  const commit = vi.fn().mockResolvedValueOnce(undefined).mockRejectedValueOnce(new Error("offline"));
  const first = await saveBulkTransactions(rows, vi.fn(), commit);
  expect(first.savedIds).toHaveLength(10);
  expect(first.failedIds).toEqual(rows.slice(10, 20).map((row) => row.id));
  expect(commit).toHaveBeenCalledTimes(2);
  const retry = vi.fn().mockResolvedValue(undefined);
  const second = await saveBulkTransactions(rows.filter((row) => !first.savedIds.includes(row.id)), vi.fn(), retry);
  expect(second.savedIds).toEqual(rows.slice(10).map((row) => row.id));
  expect(retry.mock.calls.flatMap(([chunk]) => chunk)).toEqual(rows.slice(10));
});
it("preflights document sizes before any write and also chunks by bytes", async () => {
  const rows = transactions(3).map((row) => ({ ...row, branchName: "x".repeat(400_000) }));
  expect(chunkBulkTransactions(rows).map((chunk) => chunk.length)).toEqual([2, 1]);
  rows[2].branchName = "x".repeat(500_001);
  await expect(saveBulkTransactions(rows, vi.fn())).rejects.toThrow();
  expect(mock.commit).not.toHaveBeenCalled();
});
